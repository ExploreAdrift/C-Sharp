class Samurai
{
    public string Name { get; set; }
    public int Strength { get; set; }
    public int Intelligence { get; set; }
    public int Dexterity { get; set; }
    private int health { get; set; }
     
    public Samurai(string name)
    {
        Name = name;
        Strength = 3;
        Intelligence = 3;
        Dexterity = 3;
        health = 200;
    }
     
    public Samurai(string name, int str, int intel, int dex, int hp)
    {
        Name = name;
        Strength = str;
        Intelligence = intel;
        Dexterity = dex;
        health = hp;
    }
     
    // Build Attack method
    public int Attack(Samurai target)
    {
        int dmg = Intelligence * 5;
        target.health -= dmg;
        Console.WriteLine($"{Name} attacked {target.Name} for {dmg} damage!");
        return target.health;
    }
    public int Meditate(Samurai)
    {
        Samurai.health += {dmg}
        Console.WriteLine($"{Name} healed {Samurai.Name} for {hp}");
        return target.health;
    }
}