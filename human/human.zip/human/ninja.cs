class Ninja
{
    public string Name { get; set; }
    public int Strength { get; set; }
    public int Intelligence { get; set; }
    public int Dexterity { get; set; }
    private int health { get; set; }
     
    public Ninja(string name)
    {
        Name = name;
        Strength = 3;
        Intelligence = 3;
        Dexterity = 175;
        health = 100;
    }
     
    public Ninja(string name, int str, int intel, int dex, int hp)
    {
        Name = name;
        Strength = str;
        Intelligence = intel;
        Dexterity = dex;
        health = hp;
    }
     
    // Build Attack method
    public int Attack(Ninja target)
    {
        int dmg = Intelligence * 5;
        target.health -= dmg;
        Console.WriteLine($"{Name} attacked {target.Name} for {dmg} damage!");
        return target.health;
    }
    public int Heal(Ninja)
    {
        Wizard.health += 10 * Intelligence
        Console.WriteLine($"{Name} stole from {Human.Name} for {dmg} and gained {hp}");
        return target.health;
    }
}