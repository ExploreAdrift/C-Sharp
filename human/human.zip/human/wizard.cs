class Wizard
{
    public string Name { get; set; }
    public int Strength { get; set; }
    public int Intelligence { get; set; }
    public int Dexterity { get; set; }
    private int health { get; set; }
     
    public Wizard(string name)
    {
        Name = name;
        Strength = 3;
        Intelligence = 25;
        Dexterity = 3;
        health = 50;
    }
     
    public Wizard(string name, int str, int intel, int dex, int hp)
    {
        Name = name;
        Strength = str;
        Intelligence = intel;
        Dexterity = dex;
        health = hp;
    }
     
    // Build Attack method
    public int Attack(Wizard target)
    {
        int dmg = Intelligence * 5;
        target.health -= dmg;
        Console.WriteLine($"{Name} attacked {target.Name} for {dmg} damage!");
        return target.health;
    }
    public int Heal(Wizard)
    {
        Wizard.health += 10 * Intelligence
        Console.WriteLine($"{Name} healed {Wizard.Name} for {hp}");
        return target.health;
    }
}