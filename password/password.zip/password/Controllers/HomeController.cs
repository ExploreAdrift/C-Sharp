﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using password.Models;
using Microsoft.AspNetCore.Http;



namespace password.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }
    [HttpGet("")]
    public IActionResult Index()
    {
        if (HttpContext.Session.GetInt32("NewPassword") == null)
        {
            HttpContext.Session.SetInt32("NewPassword", 1);
        }
        else
        {
            // TO RETRIEVE AN INT FROM SESSION WE USE ".GetInt32"
            int? count = HttpContext.Session.GetInt32("NewPassword");
            // CONVERT BECAUSE THIS SHIT IS A STRING
            int newCounted = Convert.ToInt32(count);
            // WE ADD ONE PER CLICK
            newCounted += 1;
            // TO STORE AN INT IN SESSION WE USE ".SetInt32"
            HttpContext.Session.SetInt32("NewPassword", newCounted);

        }
        Random rand = new Random();
        // USE THESE TO PULL FROM
        string letNum = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        // FILL IN PASSWORD
        string NewPassword = "";
        // MUST BE 14 LETTERS
        for (int i = 0; i < 15; i++)
        {
            NewPassword += letNum[rand.Next(0, letNum.Length)];
            // NewPassWord IS BEING ACTUALLY RANDOMIZED HERE AND SENT
        }
        return View("Index", NewPassword);
    }

    [HttpPost("NewPass")]

    public IActionResult NewPass()
    {
        return RedirectToAction("Index");
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
