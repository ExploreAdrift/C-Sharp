using System.ComponentModel.DataAnnotations;
namespace password.Models;

public class Passwords
{
    public string NewPassword { get; set; } = null!;
}