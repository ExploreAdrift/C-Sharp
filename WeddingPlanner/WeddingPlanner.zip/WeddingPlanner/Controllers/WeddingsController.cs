using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using WeddingPlanner.Models;
using Microsoft.EntityFrameworkCore;

namespace WeddingPlanner.Controllers;

public class WeddingsController : Controller
{
    private WeddingContext db;

    public WeddingsController(WeddingContext context)
    {
        db = context;
    }

    private int? userid
    {
        get
        {
            return HttpContext.Session.GetInt32("UserId");
        }
    }
    // Short hand for session


    private bool loggedIn
    {
        get
        {
            return userid != null;
        }
    }
    // shorthand if the user is logged in through session


    [HttpGet("wedding/new")]
    public IActionResult New()
    {

        if (!loggedIn)
        {
            return RedirectToAction("Register", "Users");
        }
        // Checking to see if user is logged in and directing them to register if not

        return View("New");
        // otherwise we are sending them to the "new" view
    }

    [HttpPost("wedding/create")]
    public IActionResult Create(Wedding newWedding)
    {
        if (userid == null)
        {
            return RedirectToAction("Register", "Users");
        }
        if (newWedding.Date < DateTime.Now)
        {
            ModelState.AddModelError("Date", "Your wedding cannot be in the past!");
        }
        if (ModelState.IsValid == false)
        {
            return View("new");
        }

        newWedding.UserId = (int)userid;

        db.Weddings.Add(newWedding);
        db.SaveChanges();

        return RedirectToAction("Dashboard");
    }

    [HttpGet("/dashboard")]
    public IActionResult Dashboard()
    {
        if (!loggedIn)
        {
            return RedirectToAction("Register", "Users");
        }

        List<Wedding> weddings = db.Weddings.Include(w => w.Creator).Include(r => r.Rsvps).Where(w => w.Date > DateTime.Now).ToList();

        return View("Dashboard", weddings);
    }

    [HttpGet("weddings/{WeddingId}")]
    public IActionResult OneWedding(int WeddingId)
    {
        if (!loggedIn)
        {
            return RedirectToAction("Register", "Users");
        }

        Wedding? wedding = db.Weddings.Include(w => w.Creator).Include(r => r.Rsvps).ThenInclude(r => r.user).FirstOrDefault(w => w.WeddingId == WeddingId);

        if (wedding == null)
        {
            return RedirectToAction("Dashboard");
        }

        return View("OneWedding", wedding);
    }

    [HttpPost("/weddings/{WeddingId}/rsvp")]
    public IActionResult RSVP(int WeddingId)
    {
        if (!loggedIn)
        {
            return RedirectToAction("Register", "Users");
        }

        Rsvp? existingRsvp = db.Rsvps.FirstOrDefault(r => r.UserId == userid && r.WeddingId == WeddingId);

        if (existingRsvp == null)
        {
            Rsvp newRsvp = new Rsvp()
            {
                WeddingId = WeddingId,
                UserId = (int)userid
            };

            db.Rsvps.Add(newRsvp);
        }
        else
        {
            db.Rsvps.Remove(existingRsvp);
        }
        db.SaveChanges();
        return RedirectToAction("Dashboard");
    }









    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
